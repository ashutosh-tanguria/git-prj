import type { RadixTree } from './types.js';
export type FuzzyResult<T> = [T, number];
export type FuzzyResults<T> = Map<string, FuzzyResult<T>>;
export declare const fuzzySearch: <T = any>(node: RadixTree<T>, query: string, maxDistance: number) => FuzzyResults<T>;
export default fuzzySearch;
