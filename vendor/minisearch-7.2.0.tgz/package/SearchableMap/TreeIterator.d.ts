import type { RadixTree, Entry, LeafType } from './types.js';
declare const ENTRIES = "ENTRIES";
declare const KEYS = "KEYS";
declare const VALUES = "VALUES";
declare const LEAF: LeafType;
interface Iterators<T> {
    ENTRIES: Entry<T>;
    KEYS: string;
    VALUES: T;
}
type Kind<T> = keyof Iterators<T>;
type Result<T, K extends keyof Iterators<T>> = Iterators<T>[K];
type IteratorPath<T> = {
    node: RadixTree<T>;
    keys: string[];
}[];
export type IterableSet<T> = {
    _tree: RadixTree<T>;
    _prefix: string;
};
declare class TreeIterator<T, K extends Kind<T>> implements Iterator<Result<T, K>> {
    set: IterableSet<T>;
    _type: K;
    _path: IteratorPath<T>;
    constructor(set: IterableSet<T>, type: K);
    next(): IteratorResult<Result<T, K>>;
    dive(): IteratorResult<Result<T, K>>;
    backtrack(): void;
    key(): string;
    value(): T;
    result(): Result<T, K>;
    [Symbol.iterator](): this;
}
export { TreeIterator, ENTRIES, KEYS, VALUES, LEAF };
