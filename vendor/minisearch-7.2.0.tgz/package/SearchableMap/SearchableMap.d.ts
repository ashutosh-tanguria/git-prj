import { TreeIterator } from './TreeIterator.js';
import { type FuzzyResults } from './fuzzySearch.js';
import type { RadixTree, Entry } from './types.js';
export default class SearchableMap<T = any> {
    _tree: RadixTree<T>;
    _prefix: string;
    private _size;
    constructor(tree?: RadixTree<T>, prefix?: string);
    atPrefix(prefix: string): SearchableMap<T>;
    clear(): void;
    delete(key: string): void;
    entries(): TreeIterator<T, "ENTRIES">;
    forEach(fn: (key: string, value: T, map: SearchableMap) => void): void;
    fuzzyGet(key: string, maxEditDistance: number): FuzzyResults<T>;
    get(key: string): T | undefined;
    has(key: string): boolean;
    keys(): TreeIterator<T, "KEYS">;
    set(key: string, value: T): SearchableMap<T>;
    get size(): number;
    update(key: string, fn: (value: T | undefined) => T): SearchableMap<T>;
    fetch(key: string, initial: () => T): T;
    values(): TreeIterator<T, "VALUES">;
    [Symbol.iterator](): TreeIterator<T, "ENTRIES">;
    static from<T = any>(entries: Iterable<Entry<T>> | Entry<T>[]): SearchableMap<any>;
    static fromObject<T = any>(object: {
        [key: string]: T;
    }): SearchableMap<any>;
}
