const ENTRIES = 'ENTRIES';
const KEYS = 'KEYS';
const VALUES = 'VALUES';
const LEAF = '';
class TreeIterator {
    set;
    _type;
    _path;
    constructor(set, type) {
        const node = set._tree;
        const keys = Array.from(node.keys());
        this.set = set;
        this._type = type;
        this._path = keys.length > 0 ? [{ node, keys }] : [];
    }
    next() {
        const value = this.dive();
        this.backtrack();
        return value;
    }
    dive() {
        if (this._path.length === 0) {
            return { done: true, value: undefined };
        }
        const { node, keys } = last(this._path);
        if (last(keys) === LEAF) {
            return { done: false, value: this.result() };
        }
        const child = node.get(last(keys));
        this._path.push({ node: child, keys: Array.from(child.keys()) });
        return this.dive();
    }
    backtrack() {
        if (this._path.length === 0) {
            return;
        }
        const keys = last(this._path).keys;
        keys.pop();
        if (keys.length > 0) {
            return;
        }
        this._path.pop();
        this.backtrack();
    }
    key() {
        return this.set._prefix + this._path
            .map(({ keys }) => last(keys))
            .filter(key => key !== LEAF)
            .join('');
    }
    value() {
        return last(this._path).node.get(LEAF);
    }
    result() {
        switch (this._type) {
            case VALUES: return this.value();
            case KEYS: return this.key();
            default: return [this.key(), this.value()];
        }
    }
    [Symbol.iterator]() {
        return this;
    }
}
const last = (array) => {
    return array[array.length - 1];
};
export { TreeIterator, ENTRIES, KEYS, VALUES, LEAF };
