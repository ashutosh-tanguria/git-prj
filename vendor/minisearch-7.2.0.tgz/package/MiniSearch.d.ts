import SearchableMap from './SearchableMap/SearchableMap.js';
export type LowercaseCombinationOperator = 'or' | 'and' | 'and_not';
export type CombinationOperator = LowercaseCombinationOperator | Uppercase<LowercaseCombinationOperator> | Capitalize<LowercaseCombinationOperator>;
export type SearchOptions = {
    fields?: string[];
    filter?: (result: SearchResult) => boolean;
    boost?: {
        [fieldName: string]: number;
    };
    boostTerm?: (term: string, i: number, terms: string[]) => number;
    weights?: {
        fuzzy: number;
        prefix: number;
    };
    boostDocument?: (documentId: any, term: string, storedFields?: Record<string, unknown>) => number;
    prefix?: boolean | ((term: string, index: number, terms: string[]) => boolean);
    fuzzy?: boolean | number | ((term: string, index: number, terms: string[]) => boolean | number);
    maxFuzzy?: number;
    combineWith?: CombinationOperator;
    tokenize?: (text: string) => string[];
    processTerm?: (term: string) => string | string[] | null | undefined | false;
    bm25?: BM25Params;
};
type SearchOptionsWithDefaults = SearchOptions & {
    boost: {
        [fieldName: string]: number;
    };
    weights: {
        fuzzy: number;
        prefix: number;
    };
    prefix: boolean | ((term: string, index: number, terms: string[]) => boolean);
    fuzzy: boolean | number | ((term: string, index: number, terms: string[]) => boolean | number);
    maxFuzzy: number;
    combineWith: CombinationOperator;
    bm25: BM25Params;
};
export type Options<T = any> = {
    fields: string[];
    idField?: string;
    storeFields?: string[];
    extractField?: (document: T, fieldName: string) => any;
    stringifyField?: (fieldValue: any, fieldName: string) => string;
    tokenize?: (text: string, fieldName?: string) => string[];
    processTerm?: (term: string, fieldName?: string) => string | string[] | null | undefined | false;
    logger?: (level: LogLevel, message: string, code?: string) => void;
    autoVacuum?: boolean | AutoVacuumOptions;
    searchOptions?: SearchOptions;
    autoSuggestOptions?: SearchOptions;
};
type OptionsWithDefaults<T = any> = Options<T> & {
    storeFields: string[];
    idField: string;
    extractField: (document: T, fieldName: string) => any;
    stringifyField: (fieldValue: any, fieldName: string) => string;
    tokenize: (text: string, fieldName: string) => string[];
    processTerm: (term: string, fieldName: string) => string | string[] | null | undefined | false;
    logger: (level: LogLevel, message: string, code?: string) => void;
    autoVacuum: false | AutoVacuumOptions;
    searchOptions: SearchOptionsWithDefaults;
    autoSuggestOptions: SearchOptions;
};
type LogLevel = 'debug' | 'info' | 'warn' | 'error';
export type Suggestion = {
    suggestion: string;
    terms: string[];
    score: number;
};
export type MatchInfo = {
    [term: string]: string[];
};
export type SearchResult = {
    id: any;
    terms: string[];
    queryTerms: string[];
    score: number;
    match: MatchInfo;
    [key: string]: any;
};
export type AsPlainObject = {
    documentCount: number;
    nextId: number;
    documentIds: {
        [shortId: string]: any;
    };
    fieldIds: {
        [fieldName: string]: number;
    };
    fieldLength: {
        [shortId: string]: number[];
    };
    averageFieldLength: number[];
    storedFields: {
        [shortId: string]: any;
    };
    dirtCount?: number;
    index: [string, {
        [fieldId: string]: SerializedIndexEntry;
    }][];
    serializationVersion: number;
};
export type QueryCombination = SearchOptions & {
    queries: Query[];
};
export type Wildcard = typeof MiniSearch.wildcard;
export type Query = QueryCombination | string | Wildcard;
export type VacuumOptions = {
    batchSize?: number;
    batchWait?: number;
};
export type VacuumConditions = {
    minDirtCount?: number;
    minDirtFactor?: number;
};
export type AutoVacuumOptions = VacuumOptions & VacuumConditions;
type DocumentTermFreqs = Map<number, number>;
type FieldTermData = Map<number, DocumentTermFreqs>;
export default class MiniSearch<T = any> {
    protected _options: OptionsWithDefaults<T>;
    protected _index: SearchableMap<FieldTermData>;
    protected _documentCount: number;
    protected _documentIds: Map<number, any>;
    protected _idToShortId: Map<any, number>;
    protected _fieldIds: {
        [key: string]: number;
    };
    protected _fieldLength: Map<number, number[]>;
    protected _avgFieldLength: number[];
    protected _nextId: number;
    protected _storedFields: Map<number, Record<string, unknown>>;
    protected _dirtCount: number;
    private _currentVacuum;
    private _enqueuedVacuum;
    private _enqueuedVacuumConditions;
    static readonly wildcard: unique symbol;
    constructor(options: Options<T>);
    add(document: T): void;
    addAll(documents: readonly T[]): void;
    addAllAsync(documents: readonly T[], options?: {
        chunkSize?: number;
    }): Promise<void>;
    remove(document: T): void;
    removeAll(documents?: readonly T[]): void;
    discard(id: any): void;
    private maybeAutoVacuum;
    discardAll(ids: readonly any[]): void;
    replace(updatedDocument: T): void;
    vacuum(options?: VacuumOptions): Promise<void>;
    private conditionalVacuum;
    private performVacuuming;
    private vacuumConditionsMet;
    get isVacuuming(): boolean;
    get dirtCount(): number;
    get dirtFactor(): number;
    has(id: any): boolean;
    getStoredFields(id: any): Record<string, unknown> | undefined;
    search(query: Query, searchOptions?: SearchOptions): SearchResult[];
    autoSuggest(queryString: string, options?: SearchOptions): Suggestion[];
    get documentCount(): number;
    get termCount(): number;
    static loadJSON<T = any>(json: string, options: Options<T>): MiniSearch<T>;
    static loadJSONAsync<T = any>(json: string, options: Options<T>): Promise<MiniSearch<T>>;
    static getDefault(optionName: string): any;
    static loadJS<T = any>(js: AsPlainObject, options: Options<T>): MiniSearch<T>;
    static loadJSAsync<T = any>(js: AsPlainObject, options: Options<T>): Promise<MiniSearch<T>>;
    private static instantiateMiniSearch;
    private executeQuery;
    private executeQuerySpec;
    private executeWildcardQuery;
    private combineResults;
    toJSON(): AsPlainObject;
    private termResults;
    private addTerm;
    private removeTerm;
    private warnDocumentChanged;
    private addDocumentId;
    private addFields;
    private addFieldLength;
    private removeFieldLength;
    private saveStoredFields;
}
export type BM25Params = {
    k: number;
    b: number;
    d: number;
};
interface SerializedIndexEntry {
    [key: string]: number;
}
export {};
