import MiniSearch from './MiniSearch.js';
export * from './MiniSearch.js';
export default MiniSearch;
